package BuyTicket;
import Menu.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.time.*;
import java.util.*;
import java.io.*;

public class PageBuyTicket extends JFrame implements ActionListener{
    

	JButton btn1 , btn2 , btn3 , btn4 , btn5 , btn6 , btn7 , btnNextPage,btnBackPage , btncancel;
	PaintMovie movie = new PaintMovie();
	String dateMovie = "1";
	int pageIndex = 1 ;
	int CountMovie = 0 ;
	Font font = new Font("Krungthep" , Font.BOLD , 25);
	
	ArrayList<JButton>btnTime = new ArrayList<JButton>(0);	// time movie
	
	public PageBuyTicket (){
            
		super("Select Showtime");
		setSize(1060,750);
                              this.getContentPane().setBackground(new java.awt.Color(0, 0, 51));
		setLayout(null);
		Dimension s = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)s.getWidth()/2 - this.getWidth()/2 , (int)s.getHeight()/2 - this.getHeight()/2);
						
		setBtnDay1();
		setBtnDay2();
		setBtnDay3();
		setBtnDay4();
		setBtnDay5();
		setBtnDay6();
		setBtnDay7();
		createdButtonTime();
		setBtncancel();
		setBtnNextPage();
		setBtnBackPage();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void setBtnDay1() {
		btn1 = new JButton("Today");
		btn1.setBounds(5, 10, 150,70);
		add(btn1);
		btn1.setForeground(new java.awt.Color(255, 255, 255));
                             btn1.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn1.setBackground (new java.awt.Color(153, 0, 0));
		btn1.addActionListener(this);
	}
	
	public void setBtnDay2() {
		ClassNewDate d = new ClassNewDate();
		btn2 = new JButton(d.getNextDate(Integer.parseInt(d.getDate())+1) + " " + d.getNextDay(d.getDay() , 1) + "  " + d.getMonth());
		btn2.setBounds(155, 10, 150,70);
		add(btn2);
		btn2.setForeground(new java.awt.Color(255, 255, 255));
                             btn2.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn2.setBackground (new java.awt.Color(153, 0, 0));
		btn2.addActionListener(this);
	}
	
	public void setBtnDay3() {
		ClassNewDate d = new ClassNewDate();

		btn3 = new JButton(d.getNextDate(Integer.parseInt(d.getDate())+2) + " " + d.getNextDay(d.getDay() , 2) + "  " + d.getMonth());
		btn3.setBounds(305, 10, 150,70);
		add(btn3);
		btn3.setForeground(new java.awt.Color(255, 255, 255));
                             btn3.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn3.setBackground (new java.awt.Color(153, 0, 0));
		btn3.addActionListener(this);
	}
	
	public void setBtnDay4() {
		ClassNewDate d = new ClassNewDate();

		btn4 = new JButton(d.getNextDate(Integer.parseInt(d.getDate())+3) + " " + d.getNextDay(d.getDay() , 3) + "  " + d.getMonth());
		btn4.setBounds(455, 10, 150,70);
		add(btn4);
		btn4.setForeground(new java.awt.Color(255, 255, 255));
                             btn4.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn4.setBackground (new java.awt.Color(153, 0, 0));
		btn4.addActionListener(this);
	}
	
	public void setBtnDay5() {
		ClassNewDate d = new ClassNewDate();

		btn5 = new JButton(d.getNextDate(Integer.parseInt(d.getDate())+4) + " " + d.getNextDay(d.getDay() , 4) + "  " + d.getMonth());
		btn5.setBounds(605, 10, 150,70);
		add(btn5);
		btn5.setForeground(new java.awt.Color(255, 255, 255));
                             btn5.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn5.setBackground (new java.awt.Color(153, 0, 0));;
		btn5.addActionListener(this);
	}
	
	public void setBtnDay6() {
		ClassNewDate d = new ClassNewDate();

		btn6 = new JButton(d.getNextDate(Integer.parseInt(d.getDate())+5) + " " + d.getNextDay(d.getDay() , 5) + "  " + d.getMonth());
		btn6.setBounds(755, 10, 150,70);
		add(btn6);
		btn6.setForeground(new java.awt.Color(255, 255, 255));
                             btn6.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn6.setBackground (new java.awt.Color(153, 0, 0));
		btn6.addActionListener(this);
	}
	
	public void setBtnDay7() {
		ClassNewDate d = new ClassNewDate();

		btn7 = new JButton(d.getNextDate(Integer.parseInt(d.getDate())+6) + " " + d.getNextDay(d.getDay() , 6) + "  " + d.getMonth());
		btn7.setBounds(905, 10, 150,70);
		add(btn7);
		btn7.setForeground(new java.awt.Color(255, 255, 255));
                             btn7.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btn7.setBackground (new java.awt.Color(153, 0, 0));
		btn7.addActionListener(this);
	}
	
	public void setBtncancel() {
		btncancel = new JButton("System Admin");
		btncancel.setBounds(600,680,200,35);
		add(btncancel);
		btncancel.setForeground(new java.awt.Color(255, 255, 255));
                             btncancel.setFont(new java.awt.Font("Segoe UI Black", 0, 18));;
                             btncancel.setBackground (new java.awt.Color(153, 0, 0));
		btncancel.addActionListener(this);
	}
	
	public void setBtnNextPage() {
		btnNextPage = new JButton("Next");
		btnNextPage.setBounds(980,680,70,35);
		add(btnNextPage);
		btnNextPage.setForeground(new java.awt.Color(255, 255, 255));
                             btnNextPage.setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                             btnNextPage.setBackground (new java.awt.Color(153, 0, 0));
		btnNextPage.addActionListener(this);
		if(CountMovie >2) {
			btnNextPage.setEnabled(true);
		}else {
			btnNextPage.setEnabled(false);
		}
		
	}
	
	public void setBtnBackPage() {
		
		btnBackPage = new JButton("Back");
		btnBackPage.setBounds(910,680,70,35);
		add(btnBackPage);
		btnBackPage.setForeground(new java.awt.Color(255, 255, 255));
                             btnBackPage.setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                             btnBackPage.setBackground (new java.awt.Color(153, 0, 0));;
		btnBackPage.addActionListener(this);
		btnBackPage.setEnabled(false);
	}

	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.blue);
		g.drawLine(0, 113, this.getWidth(), 113);
		g.drawLine(0, 114, this.getWidth(), 114);
		
		if (pageIndex == 1)movie.displayMovie(g, dateMovie);
		else if (pageIndex == 2)movie.displayMovie2(g, dateMovie);
	}
	
	public void initTime() { // Time of movie 1 - 4 ;
		int sizeTime1 = btnTime.size();
		for(int i = sizeTime1-1 ; i >= 0 ; i--) {
			btnTime.get(i).setVisible(false);
			btnTime.remove(i);
		}
	}
	
	public void setButtonDay(ActionEvent e) {
		if(e.getSource() == btn1 || e.getSource() == btn2 || e.getSource() == btn3 || e.getSource() == btn4 
				|| e.getSource() == btn5 ||	e.getSource() == btn6 || e.getSource() == btn7) {
			initTime();
			repaint();
			btn1.setForeground(Color.black);
			btn2.setForeground(Color.black);
			btn3.setForeground(Color.black);
			btn4.setForeground(Color.black);
			btn5.setForeground(Color.black);
			btn6.setForeground(Color.black);
			btn7.setForeground(Color.black);
			
			pageIndex = 1;
	
			if(e.getSource() == btn1) {
				dateMovie = "1";
				btn1.setForeground(Color.red);
			}else if(e.getSource() == btn2){
				dateMovie = "2";
				btn2.setForeground(Color.red);
			}else if (e.getSource() == btn3) {
				dateMovie = "3";
				btn3.setForeground(Color.red);
			}else if (e.getSource() == btn4) {
				dateMovie = "4";
				btn4.setForeground(Color.red);
			}else if (e.getSource() == btn5) {
				dateMovie = "5";
				btn5.setForeground(Color.red);
			}else if (e.getSource() == btn6) {
				dateMovie = "6";
				btn6.setForeground(Color.red);
			}else if (e.getSource() == btn7) {
				dateMovie = "7";
				btn7.setForeground(Color.red);
			}
			
			createdButtonTime();
			if(CountMovie >2) {
				btnNextPage.setEnabled(true);
			}else {
				btnNextPage.setEnabled(false);
			}
		}
	}
	
	public void createdButtonTime() {
		try {
			Scanner scan = new Scanner(new File("src/BuyTicket/day/day" +dateMovie+ ".txt"));
			int countTime = 0 ;
			int countMovie = 0 ;

			while(scan.hasNext()) {
				String s = scan.nextLine();
				int stime1 = 5 , etime1 = 10;
				int x = 10 , y = 350 ;
				if(countTime > 0) y = 650;							
				
				if(s.substring(0,4).equals("Time")) {
					countMovie++;
					if(countMovie < 3) {
						while(true) {
							// created JButton
							if(etime1>s.length())break;
							btnTime.add(new JButton(s.substring(stime1 , etime1)));
							
							// add JButton
							btnTime.get(countTime).setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                                                                                                     btnTime.get(countTime).setForeground(new java.awt.Color(255, 255, 255));
                                                                                                     btnTime.get(countTime).setBackground (new java.awt.Color(153, 0, 0));;
							
							btnTime.get(countTime).setBounds(x,y,120,50);
							add(btnTime.get(countTime));
							x += 140;
							countTime ++ ;
							stime1 += 6 ;
							etime1 += 6 ;
						}
					}else if (countMovie >= 3 && pageIndex == 2) {
						int countTimePage1 = countTime;
						for(int i = countTimePage1-1 ; i >=0 ; i--) {
							btnTime.get(i).setVisible(false);
						}
						x = 10 ; y = 350 ;
						if(countMovie == 4) {
							y = 650;
						}
						while(true) {
							// created JButton
							if(etime1>s.length())break;
							btnTime.add(new JButton(s.substring(stime1 , etime1)));
							
							// add JButton
							btnTime.get(countTime).setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                                                                                                     btnTime.get(countTime).setForeground(new java.awt.Color(255, 255, 255));
                                                                                                     btnTime.get(countTime).setBackground (new java.awt.Color(153, 0, 0));;
							
							btnTime.get(countTime).setBounds(x,y,120,50);
							add(btnTime.get(countTime));
							x += 140;
							countTime ++ ;
							stime1 += 6 ;
							etime1 += 6 ;
						}
					}
				}
			}
			this.CountMovie = countMovie;
			
			for(JButton btn : btnTime) {
				btn.addActionListener(this);
			}
		} catch (IOException ex) {
			ex.getStackTrace();
		}
		
		repaint();
	}
	
	public void actionPerformed(ActionEvent e) {
		// init Movie time
		int countIndex = 0;
		for(JButton btn : btnTime) {
			if(e.getSource() == btn) {
				new PageChooseSeat(btn.getText() , countIndex , dateMovie);
				this.dispose();
			}
			countIndex++ ;
		}
		
		if(e.getSource() == btncancel) {
			new MenuCinema(); // call packet Menu Class MenuCinema
			this.dispose();
		}else if (e.getSource() == btnNextPage) {
			pageIndex = 2;
			btnBackPage.setEnabled(true);
			btnNextPage.setEnabled(false);
			initTime();
			repaint();
			createdButtonTime();
		}else if (e.getSource() == btnBackPage) {
			btnBackPage.setEnabled(false);
			btnNextPage.setEnabled(true);
			pageIndex = 1;
			initTime();
			repaint();
			createdButtonTime();
		}else {
			setButtonDay(e);	
		}	
	}
}