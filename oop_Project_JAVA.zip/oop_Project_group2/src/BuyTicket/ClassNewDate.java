package BuyTicket;

import java.util.Date;

public class ClassNewDate {
	Date now = new Date();
	
	String day[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
	String month[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	
	public String getDay() {
		return(now.toString().substring(0,3));
	}
	
	public String getMonth() {
		return(now.toString().substring(4,7));
	}
	
	public String getDate() {
		return(now.toString().substring(8,10));
	}
	
	public String getTime() {
		return(now.toString().substring(11,19));
	}
	
	public int getNextDate(int oldDate) {
		for(int i = 0 ; i < month.length ; i++) {
			if(getMonth().equals(month[i])) {
				if (i == 1) {
					if (oldDate >= 29) {
						return ((oldDate - 29) + 1);
					}else return(oldDate + 1);
				}else if(i == 0 || i == 2 || i == 4 || i == 6 || i == 7 || i == 9 || i ==11) {
					if(oldDate >= 31) {
						return ((oldDate - 31)+1);
					}
				}else {
					if(oldDate >= 30) {
						return((oldDate - 31)+1);
					}
				}
			}
			
		}
		
		return oldDate ;
	}
	
	public String getNextDay(String oldDay , int numNextDay) {
		for(int i = 0 ; i < day.length ; i++) {
			if(oldDay.equals(day[i])){
				if(numNextDay + i >= day.length) {
					return day[(i+numNextDay)-7];
				}
				return day[i+numNextDay];
			}
		}
		return "not Found";
	}
	
	public String getNextMonth(String oldMonth , int numNextMonth) {
		for(int i = 0 ; i < month.length ; i++) {
			if(oldMonth.equals(month[i])){
				return month[i+numNextMonth];
			}
		}
		return "not Found";
	}
}