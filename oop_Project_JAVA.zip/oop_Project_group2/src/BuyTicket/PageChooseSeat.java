package BuyTicket;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.Timer;

public class PageChooseSeat extends JFrame implements ActionListener,MouseListener{
	String time ;
	int indexButton;
	String date;
	
	String nameMovie = "";
	ArrayList<ImageIcon>imgseat = new ArrayList<ImageIcon>(0);
	ArrayList<String>statusImg = new ArrayList<String>(0);
	ArrayList<String>arrSeats = new ArrayList<String>(0);
	ImageIcon imgMovie;
	int statusPaint = 0;
	Timer t = new Timer(10,this);
	int countRepaint = 0;
	
	int total = 0 ;
	int statusClick = 0;
	
	JButton btnOK = new JButton("OK") , btncancel = new JButton("cancel");
	JLabel lblTotal = new JLabel("0");
	JTextArea areaSeats = new JTextArea();
	JScrollPane scroll = new JScrollPane(areaSeats);
	
	public PageChooseSeat(String time , int indexButton , String date) {
		super("Page Choose seat");
		this.time = time;
		this.indexButton = indexButton;
		this.date = date;
		
		setSize(1060,750);
		setLayout(null);
		Dimension s = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)s.getWidth()/2 - this.getWidth()/2 , (int)s.getHeight()/2 - this.getHeight()/2);
		addMouseListener(this);
		
		t.start();
		checkNameMovie();
		imgMovie = new ImageIcon(getClass().getResource(nameMovie+".png"));
		initseat(indexButton);
		
		scroll.setBounds(260, 670, 350 , 40);
		areaSeats.setEditable(false);
		add(scroll);
		
		btnOK.setFont(new Font("KrungThep" , Font.BOLD , 14));
		btnOK.setForeground(Color.red);
		btnOK.setBounds(840,670,100,40);
		btnOK.addActionListener(this);
		btnOK.setEnabled(false);
		add(btnOK);
		
		btncancel.setFont(new Font("KrungThep" , Font.BOLD , 14));
		btncancel.setForeground(Color.red);
		btncancel.setBounds(940,670,100,40);
		btncancel.addActionListener(this);
		add(btncancel);
		
		lblTotal.setFont(new Font("KrungThep" , Font.PLAIN , 18));
		lblTotal.setBounds(750,685,80,15);
		add(lblTotal);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		
		paintDetailMovie(g);
		g.setColor(Color.BLACK);
		g.drawLine(0, 260, this.getWidth(), 260);
		g.drawLine(0, 261, this.getWidth(), 261);
		paintImage(g);
		
		g.setColor(Color.black);
		g.setFont(new Font("KrungThep",Font.BOLD,40));
		
		int y = 335;
		g.drawString("E", 60, 335);
		g.drawString("D", 60, y+(80*1));
		g.drawString("C", 60, y+(80*2));
		g.drawString("B", 60, y+(80*3));
		g.drawString("A", 60, y+(80*4));
		
		y = 335;
		g.drawString("E", 970, 335);
		g.drawString("D", 970, y+(80*1));
		g.drawString("C", 970, y+(80*2));
		g.drawString("B", 970, y+(80*3));
		g.drawString("A", 970, y+(80*4));
		
		g.setColor(Color.BLUE);
		g.setFont(new Font("KrungThep",Font.BOLD,24));
		g.drawString("Selected Seats : ", 30, 720);

		g.setFont(new Font("KrungThep",Font.BOLD,20));
		g.drawString("Total : ", 670, 720);
		
	}
	
	public void paintImage(Graphics g) {
		imgMovie.paintIcon(this, g, 10, 30);
		
		int x = 150 , y = 300;
		//img.paintIcon(this, g, 100, 100);
		int count = 1 ;
		for(ImageIcon img : imgseat) {
			img.paintIcon(this, g, x, y);
			if (count % 14 == 0) {
				y += 80 ;
				x = 95 ;
			}
			x += 55 ;
			count ++ ;
		}
	}
	
	public void paintDetailMovie(Graphics g) {
		String stGenre = "Genre : ";
		String stRate = "Rate : ";
		String stDirector = "Director : ";
		String stActors = "Actors : ";
		String stSynopsis = "Synopsis : ";
		
		g.setFont(new Font("Krungthep" , Font.PLAIN , 15));
		g.setColor(Color.black);
		
		// input Genre of movie to String detialMovie for display
		try {
			Scanner sGenre = new Scanner(new File("src/Movie/"+nameMovie+"/Genre.txt"));
			while(sGenre.hasNext()) {
				stGenre += sGenre.nextLine();
			}
			sGenre.close();
			
			Scanner sRate = new Scanner(new File("src/Movie/"+nameMovie+"/Rate.txt"));
			while(sRate.hasNext()) {
				stRate += sRate.nextLine() + " | ";
			}
			sRate.close();
			
			Scanner sTime = new Scanner(new File("src/Movie/"+nameMovie+"/Time.txt"));
			while(sTime.hasNext()) {
				stRate += sTime.nextLine() + " mins.";
			}
			sTime.close();
			
			Scanner sDirector = new Scanner(new File("src/Movie/"+nameMovie+"/Director.txt"));
			while(sDirector.hasNext()) {
				stDirector += sDirector.nextLine();
			}
			sDirector.close();
			
			Scanner sActors = new Scanner(new File("src/Movie/"+nameMovie+"/Actors.txt"));
			while(sActors.hasNext()) {
				stActors += sActors.nextLine();
			}
			sActors.close();
			
			Scanner sSynopsis = new Scanner(new File("src/Movie/"+nameMovie+"/Synopsis.txt"));
			ArrayList<String>s = new ArrayList<String>(0);
			while(sSynopsis.hasNext()) {
				s.add(sSynopsis.nextLine());
			}
			sSynopsis.close();
			
			int x = 290 , y = 170 ;
			for(String str : s) {
				g.drawString(str, x, y);
				y += 30 ;
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		g.drawString(stGenre, 200, 50);
		g.drawString(stRate, 200, 80);
		g.drawString(stDirector, 200, 110);
		g.drawString(stActors, 200, 140);
		g.drawString(stSynopsis, 200, 170);
		
	}
	
	public void initseat(int numLine) {
		try {
			Scanner scan = new Scanner(new File("src/BuyTicket/Seats/day"+date+".txt"));
			
			int countLine = 0 ;
			while(scan.hasNext()) {
				String str = scan.nextLine();
				if (numLine == countLine) {
					for(int i= 0 ; i < str.length() ; i++) {
						if(str.charAt(i) == '1') {
							imgseat.add(new ImageIcon(getClass().getResource("seat.png")));
							statusImg.add("1");
						}else {
							imgseat.add(new ImageIcon(getClass().getResource("seatSelected.png")));
							statusImg.add("2");
						}
					}
				}
				countLine ++ ;
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public void checkNameMovie() {
		try {
			Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+date+".txt"));
			ArrayList<String>arrMovie = new ArrayList<String>(0);
			int countMovie = 0;
			int countBtn = 0;
			while(scan.hasNext()) {
				String s = scan.nextLine();
				if(s.substring(0,4).equals("Time")) {
					countMovie ++ ;
					int stime1 = 5 , etime1 = 10; 
					
					while(true) {
						// created JButton
						if(etime1>s.length())break;
						countBtn ++ ;
						stime1 += 6 ;
						etime1 += 6 ;
					}
				}else {
					arrMovie.add(s);
				}
				if((countBtn-1) >= indexButton) {
					nameMovie = (arrMovie.get(countMovie-1));
					break;
				}
			}
			scan.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}


	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int x = 150 , y = 300;
		String str = "";
		//img.paintIcon(this, g, 100, 100);
		int count = 0 ;
		for(ImageIcon img : imgseat) {
			if((e.getX() >= x && e.getX() <= x+50) &&(e.getY() >= y && e.getY() <= y+45)) {
				// row 5 // E
				if(count/14 == 0) {
					if (statusImg.get(count).equals("1")) {
						arrSeats.add("E" +(count+1));
					}
					else {
						for(int i = 0 ; i < arrSeats.size() ; i++) {
							if (arrSeats.get(i).equals("E"+(count+1))) {
								arrSeats.remove(i);
							}
						}
					}
					areaSeats.setFont(new Font("Krungthep" , Font.PLAIN , 15));
					for(String s : arrSeats) {
						str += s + " , ";
					}
					if(str.length() > 2)areaSeats.setText(str.substring(0,str.length()-2));
					else areaSeats.setText("");				}
				// row 4 // D
				if(count/14 == 1) {
					if (statusImg.get(count).equals("1")) {
						arrSeats.add("D" +(count-14+1));
					}
					else {
						for(int i = 0 ; i < arrSeats.size() ; i++) {
							if (arrSeats.get(i).equals("D"+(count-14+1))) {
								arrSeats.remove(i);
							}
						}
					}
					areaSeats.setFont(new Font("Krungthep" , Font.PLAIN , 15));
					for(String s : arrSeats) {
						str += s + " , ";
					}
					if(str.length() > 2)areaSeats.setText(str.substring(0,str.length()-2));
					else areaSeats.setText("");				}
				
				// row 3 // C
				if(count/14 == 2) {
					if (statusImg.get(count).equals("1")) {
						arrSeats.add("C" +(count-28+1));
					}
					else {
						for(int i = 0 ; i < arrSeats.size() ; i++) {
							if (arrSeats.get(i).equals("C"+(count-28+1))) {
								arrSeats.remove(i);
							}
						}
					}
					areaSeats.setFont(new Font("Krungthep" , Font.PLAIN , 15));
					for(String s : arrSeats) {
						str += s + " , ";
					}
					if(str.length() > 2)areaSeats.setText(str.substring(0,str.length()-2));
					else areaSeats.setText("");
				}
				// row 2 // B
				if(count/14 == 3) {
					if (statusImg.get(count).equals("1")) {
						arrSeats.add("B" +(count-42+1));
					}
					else {
						for(int i = 0 ; i < arrSeats.size() ; i++) {
							if (arrSeats.get(i).equals("B"+(count-42+1))) {
								arrSeats.remove(i);
							}
						}
					}
					areaSeats.setFont(new Font("Krungthep" , Font.PLAIN , 15));
					for(String s : arrSeats) {
						str += s + " , ";
					}
					if(str.length() > 2)areaSeats.setText(str.substring(0,str.length()-2));
					else areaSeats.setText("");				}
				// row 1 // A
				if(count/14 == 4) {
					if (statusImg.get(count).equals("1")) {
						arrSeats.add("A" +(count-56+1));
					}
					else {
						for(int i = 0 ; i < arrSeats.size() ; i++) {
							if (arrSeats.get(i).equals("A"+(count-56+1))) {
								arrSeats.remove(i);
							}
						}
					}
					areaSeats.setFont(new Font("Krungthep" , Font.PLAIN , 15));
					for(String s : arrSeats) {
						str += s + " , ";
					}
					if(str.length() > 2)areaSeats.setText(str.substring(0,str.length()-2));
					else areaSeats.setText("");				}
				
				if(statusImg.get(count).equals("1")) {
					imgseat.set(count, new ImageIcon(getClass().getResource("seatSelected.png")));
					statusImg.set(count,"2");
				}else if(statusImg.get(count).equals("2")) {
					imgseat.set(count, new ImageIcon(getClass().getResource("seat.png")));
					statusImg.set(count,"1");
				}
				statusClick = 1 ;
			}
			
			total = arrSeats.size()*180;
			String stotal = "";
			if(total >= 1000) {
				for(int i = 0 ; i < Integer.toString(total).length() ; i++) {
					if(i == 0) {
						stotal += Integer.toString(total).charAt(i) + ",";
					}else {
						stotal += Integer.toString(total).charAt(i);
					}
				}
			}else stotal = Integer.toString(total);
			lblTotal.setText(stotal);
			
			
			if ((count +1)% 14 == 0) {
				y += 80 ;
				x = 95 ;
			}
			x += 55 ;
			count ++ ;
			
			// check have data in arrSeat for setEnebled btnOK
			if(arrSeats.size() == 0) {
				btnOK.setEnabled(false);
			}else {
				btnOK.setEnabled(true);
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if(statusClick == 1) {
			statusClick = 0;
			repaint();
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		int countLine = 0 ;
		ArrayList<String>updateSeat = new ArrayList<String>(0);
		
		if(e.getSource() == btnOK) {
			// update Seats
			try {
				int input = JOptionPane.showConfirmDialog(null, "Movie : " + nameMovie + "\nTime : " + time+"\nyou choose seat : " + areaSeats.getText() +"\nTotal : " + 
						lblTotal.getText() , "Confirm add movie", JOptionPane.OK_CANCEL_OPTION , JOptionPane.QUESTION_MESSAGE);
				
				if(input == 0) {
					Scanner scan = new Scanner(new File("src/BuyTicket/Seats/day"+date+".txt"));
					while(scan.hasNext()) {
						String s = scan.nextLine();
						if(countLine == indexButton) {
							String s1 = "";
							for(String str : statusImg) {
								s1+=str;
							}
							updateSeat.add(s1);
						}else {
							updateSeat.add(s);
						}
						countLine++;
					}
					scan.close();
					PrintWriter writer = new PrintWriter(new FileOutputStream("src/BuyTicket/Seats/day"+date+".txt"));
					for(String str : updateSeat) {
						writer.println(str);
					}
					writer.close();
				}
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			new PageBuyTicket();
			this.dispose();
		}else if (e.getSource() == btncancel) {
			new PageBuyTicket();
			this.dispose();
		}else if (countRepaint < 5) {			// refresh page
			repaint();
		}
		countRepaint++;
	}
}