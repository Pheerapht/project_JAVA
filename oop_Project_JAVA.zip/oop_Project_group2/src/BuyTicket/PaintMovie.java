package BuyTicket;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.*;
import java.awt.event.*;

public class PaintMovie extends JFrame{
	
	ImageIcon img ;
	
	public void displayMovie(Graphics g , String num) {
		Scanner scan;
		int countMovie = 0 ;
		
		try {
			scan = new Scanner(new File("src/BuyTicket/day/day" + num + ".txt"));
			while(scan.hasNext()) {
				String nameMovie = scan.nextLine();
				if(!nameMovie.substring(0,4).equals("Time")) {
					String stGenre = "Genre : ";
					String stRate = "Rate : ";
					String stDirector = "Director : ";
					String stActors = "Actors : ";
					String stSynopsis = "Synopsis : ";
					
					g.setFont(new Font("Krungthep" , Font.PLAIN , 18));
					g.setColor(Color.white);
					
					// input Genre of movie to String detialMovie for display
					Scanner sGenre = new Scanner(new File("src/Movie/"+nameMovie+"/Genre.txt"));
					while(sGenre.hasNext()) {
						stGenre += sGenre.nextLine();
					}
					sGenre.close();
					
					Scanner sRate = new Scanner(new File("src/Movie/"+nameMovie+"/Rate.txt"));
					while(sRate.hasNext()) {
						stRate += sRate.nextLine() + " | ";
					}
					sRate.close();
					
					Scanner sTime = new Scanner(new File("src/Movie/"+nameMovie+"/Time.txt"));
					while(sTime.hasNext()) {
						stRate += sTime.nextLine() + " mins.";
					}
					sTime.close();
					
					Scanner sDirector = new Scanner(new File("src/Movie/"+nameMovie+"/Director.txt"));
					while(sDirector.hasNext()) {
						stDirector += sDirector.nextLine();
					}
					sDirector.close();
					
					Scanner sActors = new Scanner(new File("src/Movie/"+nameMovie+"/Actors.txt"));
					while(sActors.hasNext()) {
						stActors += sActors.nextLine();
					}
					sActors.close();
					
					Scanner sSynopsis = new Scanner(new File("src/Movie/"+nameMovie+"/Synopsis.txt"));
					ArrayList<String>s = new ArrayList<String>(0);
					while(sSynopsis.hasNext()) {
						s.add(sSynopsis.nextLine());
					}
					sSynopsis.close();
					
					img = new ImageIcon(getClass().getResource(nameMovie+".png"));
					if (countMovie == 0) {
						img.paintIcon(this, g, 10, 140);
						g.drawString(stGenre, 200, 155);
						g.drawString(stRate, 200, 185);
						g.drawString(stDirector, 200, 215);
						g.drawString(stActors, 200, 245);
						g.drawString(stSynopsis, 200, 275);
						
						int x = 290 , y = 275 ;
						for(String str : s) {
							g.drawString(str, x, y);
							y += 30 ;
						}
						
					}else if (countMovie == 1) {
						img.paintIcon(this, g, 10, 445);
						g.drawString(stGenre, 200, 460);
						g.drawString(stRate, 200, 490);
						g.drawString(stDirector, 200, 520);
						g.drawString(stActors, 200, 550);
						g.drawString(stSynopsis, 200, 580);
						
						int x = 290 , y = 580 ;
						for(String str : s) {
							g.drawString(str, x, y);
							y += 30 ;
						}
					}
					countMovie ++ ;
				}	
			}
			scan.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void displayMovie2(Graphics g , String num) {
		Scanner scan;
		int countMovie = 0 ;
		
		try {
			scan = new Scanner(new File("src/BuyTicket/day/day" + num + ".txt"));
			while(scan.hasNext()) {
				String nameMovie = scan.nextLine();
				if(!nameMovie.substring(0,4).equals("Time")) {
					countMovie ++ ;
					String stGenre = "Genre : ";
					String stRate = "Rate : ";
					String stDirector = "Director : ";
					String stActors = "Actors : ";
					String stSynopsis = "Synopsis : ";
					
					g.setFont(new Font("Krungthep" , Font.PLAIN , 18));
					g.setColor(Color.white);
					
					// input Genre of movie to String detialMovie for display
					Scanner sGenre = new Scanner(new File("src/Movie/"+nameMovie+"/Genre.txt"));
					while(sGenre.hasNext()) {
						stGenre += sGenre.nextLine();
					}
					sGenre.close();
					
					Scanner sRate = new Scanner(new File("src/Movie/"+nameMovie+"/Rate.txt"));
					while(sRate.hasNext()) {
						stRate += sRate.nextLine() + " | ";
					}
					sRate.close();
					
					Scanner sTime = new Scanner(new File("src/Movie/"+nameMovie+"/Time.txt"));
					while(sTime.hasNext()) {
						stRate += sTime.nextLine() + " mins.";
					}
					sTime.close();
					
					Scanner sDirector = new Scanner(new File("src/Movie/"+nameMovie+"/Director.txt"));
					while(sDirector.hasNext()) {
						stDirector += sDirector.nextLine();
					}
					sDirector.close();
					
					Scanner sActors = new Scanner(new File("src/Movie/"+nameMovie+"/Actors.txt"));
					while(sActors.hasNext()) {
						stActors += sActors.nextLine();
					}
					sActors.close();
					
					Scanner sSynopsis = new Scanner(new File("src/Movie/"+nameMovie+"/Synopsis.txt"));
					ArrayList<String>s = new ArrayList<String>(0);
					while(sSynopsis.hasNext()) {
						s.add(sSynopsis.nextLine());
					}
					sSynopsis.close();
					
					img = new ImageIcon(getClass().getResource(nameMovie+".png"));
					if (countMovie == 3) {
						img.paintIcon(this, g, 10, 140);
						g.drawString(stGenre, 200, 155);
						g.drawString(stRate, 200, 185);
						g.drawString(stDirector, 200, 215);
						g.drawString(stActors, 200, 245);
						g.drawString(stSynopsis, 200, 275);
						
						int x = 290 , y = 275 ;
						for(String str : s) {
							g.drawString(str, x, y);
							y += 30 ;
						}
						
					}else if (countMovie == 4) {
						img.paintIcon(this, g, 10, 445);
						g.drawString(stGenre, 200, 460);
						g.drawString(stRate, 200, 490);
						g.drawString(stDirector, 200, 520);
						g.drawString(stActors, 200, 550);
						g.drawString(stSynopsis, 200, 580);
						
						int x = 290 , y = 580 ;
						for(String str : s) {
							g.drawString(str, x, y);
							y += 30 ;
						}
					}
				}	
			}
			scan.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}