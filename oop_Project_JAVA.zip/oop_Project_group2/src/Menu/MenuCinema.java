package Menu;
import java.awt.*;
import javax.swing.Timer;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class MenuCinema extends JFrame implements ActionListener{
	int countTime = 0 ;
	
	JButton btnEdit = new JButton("Edit");
	JButton btnBuy = new JButton("Buy ticket");
	Font font = new Font("Krungthep" , Font.PLAIN , 32);
	ImageIcon img = new ImageIcon(getClass().getResource("Img.png"));
	
	public MenuCinema() {
		// set window gui
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(750,500);
		setLocation((int)screen.getWidth()/2 - this.getWidth()/2 , (int)screen.getHeight()/2 - this.getHeight()/2);
		setLayout(null);
		
		// add button edit
		btnEdit.setForeground(new java.awt.Color(255, 255, 255));
                             btnEdit.setFont(new java.awt.Font("Segoe UI Black", 0, 36));
		btnEdit.setBounds(420,300,250,80);
		btnEdit.setBackground (new java.awt.Color(153, 0, 0));
		btnEdit.setBounds(125,300,200,80);
		btnEdit.addActionListener(this);
		add(btnEdit);
		
		// add button but ticket
                             btnBuy.setForeground(new java.awt.Color(255, 255, 255));
                             btnBuy.setFont(new java.awt.Font("Segoe UI Black", 0, 36));
		btnBuy.setBounds(420,300,250,80);
		btnBuy.setBackground (new java.awt.Color(153, 0, 0));
		btnBuy.addActionListener(this);
		add(btnBuy);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == btnEdit) {
			new EditMovie.PageEdit();
			this.dispose();
		}else if (e.getSource() == btnBuy) {
			new BuyTicket.PageBuyTicket();
			this.dispose();
		}
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		img.paintIcon(this, g, 0, 10);
		
	}
}