
public class MainCinema {
	
	public static void main(String[] args) {
		new BuyTicket.PageBuyTicket();	
	}
}





