package EditMovie;

import javax.swing.*;
import BuyTicket.ClassNewDate;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class PageDeleteMovieTime extends JFrame implements ActionListener {
	
	Font font = new Font("Krungthep" , Font.PLAIN , 26);
	Font font2 = new Font("Krungthep" , Font.PLAIN , 16);
	Font font3 = new Font("Krungthep" , Font.PLAIN , 14);
	
	JComboBox comboDate , comboName , comboTime ;
	
	JButton btnOK = new JButton("OK");
	JButton btncancel = new JButton("cancel");
	
	ClassNewDate n = new ClassNewDate();
	int date[] = {Integer.parseInt(n.getDate()) , 1+Integer.parseInt(n.getDate()) , 2+Integer.parseInt(n.getDate()) , 3+Integer.parseInt(n.getDate()) ,
			4+Integer.parseInt(n.getDate()) , 5+Integer.parseInt(n.getDate()) , 6+Integer.parseInt(n.getDate())};
	
	public PageDeleteMovieTime() {
		super("Set movie showtime");
		setSize(500,350);
		setLayout(null);
		Dimension s = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)s.getWidth()/2 - this.getWidth()/2 , (int)s.getHeight()/2 - this.getHeight()/2);
		
		setComboDate();
		setComboName();
		setComboTime();
		
		btnOK.setBounds(90 , 225, 130,40);
		btnOK.addActionListener(this);
		add(btnOK);
		
		btncancel.setBounds(270 , 225 , 130,40);
		btncancel.addActionListener(this);
		add(btncancel);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void setComboDate() {
		String str[] = new String[date.length];
		for(int i = 0 ; i < date.length ; i++) {
			str[i] = Integer.toString(date[i]);
		}
		comboDate = new JComboBox(str);
		comboDate.addActionListener(this);
		comboDate.setFont(font3);
		comboDate.setBounds(250 , 85 , 150,30);
		add(comboDate);
	}
	
	public void setComboName() {
		comboName = new JComboBox();
		try {
			for(int i = 1 ; i <= 7 ; i++) {
				PrintWriter writer = new PrintWriter(new FileOutputStream("src/BuyTicket/day/day"+i+".txt" , true));
				writer.close();
			}
			Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+(comboDate.getSelectedIndex()+1) + ".txt"));
			ArrayList<String>arrName = new ArrayList<String>();
			while(scan.hasNext()) {
				String str2 = scan.nextLine();
				if(!str2.substring(0,4).equals("Time")) {
					arrName.add(str2);
				}
			}
			
			for(String str : arrName) {
				comboName.addItem(str);
			}
			scan.close();
		}catch(IOException ex) {
			ex.printStackTrace();
		}
		
		comboName.setFont(font3);
		comboName.addActionListener(this);
		comboName.setBounds(250 , 125 , 200,30);
		add(comboName);
	}
	
	public void setComboTime() {
		comboTime = new JComboBox();
		int countMovie = 0;
		try {
			Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+(comboDate.getSelectedIndex()+1) + ".txt"));
			ArrayList<String>arrTime = new ArrayList<String>();
			int start = 5 , end = 10 ;
			while(scan.hasNext()) {
				String str2 = scan.nextLine();
				if(str2.substring(0,4).equals("Time")) {
					if(countMovie == comboName.getSelectedIndex()) {
						while(true) {
							if(end > str2.length())break;
							arrTime.add(str2.substring(start,end));
							start += 6 ; end += 6 ;
						}
					}
					countMovie ++;
				}
			}
			comboTime.removeAllItems();
			for(String str : arrTime) {
				comboTime.addItem(str);
			}					
			scan.close();
		}catch(IOException ex) {
			ex.getStackTrace();
		}
		
		comboTime.setFont(font3);
		comboTime.setBounds(250 , 165 , 150,30);
		add(comboTime);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.black);
		g.setFont(font);
		g.drawString("Delete movie showtime", 85, 65);
		
		g.setColor(Color.black);
		g.setFont(font2);
		g.drawString("Select Date Movie : ",60, 125);
		
		g.setColor(Color.black);
		g.setFont(font2);
		g.drawString("Select Name Movie : ", 50, 165);
		
		g.setColor(Color.black);
		g.setFont(font2);
		g.drawString("Select Time Movie : ", 60, 205);
	}

	public void actionPerformed(ActionEvent e) {
		ArrayList<String>arrName = new ArrayList<String>(0);
		
		if(e.getSource() == comboDate || e.getSource() == comboName) {
			if(e.getSource() == comboDate) {
				try {
					Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+(comboDate.getSelectedIndex()+1)+".txt"));
					while(scan.hasNext()) {
						String str = scan.nextLine();
						if(!str.substring(0,4).equals("Time")) {
							arrName.add(str);
						}else {
							
						}
					}
					
					comboName.removeAllItems();
					for(String str : arrName) {
						comboName.addItem(str);
					}
					scan.close();
					
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
			}else if (e.getSource() == comboName) {
				int countMovie = 0;
				try {
					Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+(comboDate.getSelectedIndex()+1) + ".txt"));
					ArrayList<String>arrTime = new ArrayList<String>();
					int start = 5 , end = 10 ;
					while(scan.hasNext()) {
						String str2 = scan.nextLine();
						if(str2.substring(0,4).equals("Time")) {
							if(countMovie == comboName.getSelectedIndex()) {
								while(true) {
									if(end > str2.length())break;
									arrTime.add(str2.substring(start,end));
									start += 6 ; end += 6 ;
								}
							}
							countMovie ++;
						}
					}
					comboTime.removeAllItems();
					for(String str : arrTime) {
						comboTime.addItem(str);
					}					
					scan.close();
				}catch(IOException ex) {
					ex.printStackTrace();
				}
			}
		}else if (e.getSource() == btnOK) {
			String nameMovie = (String) comboName.getSelectedItem();
			String timeMovie = (String) comboTime.getSelectedItem();
			int dateMovie = comboDate.getSelectedIndex()+1;
			int input = JOptionPane.showConfirmDialog(null, "Movie : " + nameMovie + "\nTime : " + timeMovie+"\nYou comfirm to delete"
					, "Confirm add movie", JOptionPane.OK_CANCEL_OPTION , JOptionPane.QUESTION_MESSAGE);
			
			if(input == 0) {
				// delete Seats
				try {
					Scanner scan2 = new Scanner(new File("src/BuyTicket/Seats/day"+dateMovie+".txt"));
					ArrayList<String>arrTime1 = new ArrayList<String>(0);
					while(scan2.hasNext()) {
						String str2 = scan2.nextLine();
						arrTime1.add(str2);
					}
					scan2.close();
					
					PrintWriter writer = new PrintWriter(new FileOutputStream("src/BuyTicket/Seats/day"+dateMovie+".txt"));
					int countTime1 = 0 ;
					for(String str3 : arrTime1) {
						if(countTime1 != comboTime.getSelectedIndex())writer.println(str3);
						countTime1++;
					}
					writer.close();
				} catch (FileNotFoundException e2) {
					e2.printStackTrace();
				}
				
				// delete Time
				ArrayList<String>newString = new ArrayList<String>(0);
				ArrayList<String>arrTime = new ArrayList<String>(0);
				boolean flagTime = false ;
				// search name time date to delete
				try {
					Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+dateMovie+".txt"));
					while(scan.hasNext()) {
						String str = scan.nextLine();
						if(flagTime == true) {
							newString.add("1");
							flagTime = false ;
							int start = 5 ; int end = 10 ;
							while(true) {
								if(end >= str.length())break;
								arrTime.add(str.substring(start,end));
								start+=6;
								end+=6;					
							}
						}else {
							newString.add(str);
						}
						if(str.equals(nameMovie))flagTime = true;
					}
					scan.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				// rewrite field day of date to delete new
				try {
					PrintWriter writer = new PrintWriter(new FileOutputStream("src/BuyTicket/day/day"+dateMovie+".txt"));
					for(String str : newString) {
						if(str.equals("1")) {
							writer.print("Time");
							for(String str2 : arrTime) {
								if(!str2.equals(comboTime.getSelectedItem()))writer.print(" " + str2);
							}
							writer.println();
						}else {
							writer.println(str);
						}
					}
					writer.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				int countMovie = 0;
				try {
					Scanner scan = new Scanner(new File("src/BuyTicket/day/day"+(comboDate.getSelectedIndex()+1) + ".txt"));
					ArrayList<String>arrTime2 = new ArrayList<String>();
					int start = 5 , end = 10 ;
					while(scan.hasNext()) {
						String str2 = scan.nextLine();
						if(str2.substring(0,4).equals("Time")) {
							if(countMovie == comboName.getSelectedIndex()) {
								while(true) {
									if(end > str2.length())break;
									arrTime2.add(str2.substring(start,end));
									start += 6 ; end += 6 ;
								}
							}
							countMovie ++;
						}
					}
					comboTime.removeAllItems();
					for(String str : arrTime2) {
						comboTime.addItem(str);
					}
					
					if(arrTime2.size() == 0) {
						File file = new File("src/BuyTicket/day/day"+dateMovie+".txt");
						file.delete();
					}
					scan.close();
				}catch(IOException ex) {
					ex.printStackTrace();
				}				
			}
		}else if (e.getSource() == btncancel) {
			new PageEdit();
			this.dispose();
		}
	}
}