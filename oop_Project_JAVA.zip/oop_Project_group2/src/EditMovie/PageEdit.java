package EditMovie;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import Menu.*;

public class PageEdit extends JFrame implements ActionListener{
	JButton btnAdd = new JButton("Add Movie");
	JButton btnDelete = new JButton("Delete Movie showtime");
	JButton btnEdit = new JButton("Add Movie showtime");
	JButton btncancel = new JButton("cancel");

	Font font1 = new Font("Krungthep" , Font.PLAIN , 20);
	Font font2 = new Font("Krungthep" , Font.PLAIN , 14);

	public PageEdit() {
		setGUI();
	}
	
	public void setGUI() {
		setSize(500,500);
                 this.getContentPane().setBackground(new java.awt.Color(0, 0, 51));
		Container c = getContentPane();
		c.setLayout(null);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)screen.getWidth()/2 - getWidth()/2 , (int)screen.getHeight()/2 - getHeight()/2);
		
		btnAdd.setForeground(new java.awt.Color(255, 255, 255));
                             btnAdd.setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                             btnAdd.setBackground (new java.awt.Color(153, 0, 0));;
		btnAdd.setBounds(155, 30 , 200 , 75);
		btnAdd.addActionListener(this);
		c.add(btnAdd);
		
		btnDelete.setForeground(new java.awt.Color(255, 255, 255));
                             btnDelete.setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                             btnDelete.setBackground (new java.awt.Color(153, 0, 0));;
		btnDelete.setBounds(155, 140 , 200 , 75);
		btnDelete.addActionListener(this);
		c.add(btnDelete);
		
		btnEdit.setForeground(new java.awt.Color(255, 255, 255));
                             btnEdit.setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                             btnEdit.setBackground (new java.awt.Color(153, 0, 0));;
		btnEdit.setBounds(155, 250 , 200 , 75);
		btnEdit.addActionListener(this);
		c.add(btnEdit);
		
		btncancel.setForeground(new java.awt.Color(255, 255, 255));
                             btncancel.setFont(new java.awt.Font("Segoe UI Black", 0, 15));;
                             btncancel.setBackground (new java.awt.Color(153, 0, 0));;
		btncancel.setBounds(155, 360 , 200 , 75);
		btncancel.addActionListener(this);
		c.add(btncancel);
		
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnAdd) {
			new PageAddMovie();
			this.dispose();
		}else if (e.getSource() == btnDelete) {
			new PageDeleteMovieTime();
			this.dispose();
		}else if (e.getSource() == btnEdit) {
			new PageSetMovie();
			this.dispose();
		}else if(e.getSource() == btncancel) {
			new MenuCinema(); // Menu.MenuCinema();
			this.dispose();
		}
	}
}
