package EditMovie;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

import javax.swing.*;
import BuyTicket.ClassNewDate;

public class PageSetMovie extends JFrame implements ActionListener{
	JLabel lblSetmovie = new JLabel("Set movie showtime");
	JLabel lbldate = new JLabel("Select date to add movie : ");
	JLabel lblTime = new JLabel("Enter time of movie : ");
	
	JTextField fieldTime = new JTextField();
	
	JButton btnAddDate = new JButton("Add");
	JButton btnAddTime = new JButton("Add");
	JButton btnOK = new JButton("OK");
	JButton btncancel = new JButton("cancel");
	
	String strArea = "";
	JTextArea areaDateTime = new JTextArea();
	
	int countTime = 0 ;
	
	ClassNewDate n = new ClassNewDate();
	int date[] = {Integer.parseInt(n.getDate()) , 1+Integer.parseInt(n.getDate()) , 2+Integer.parseInt(n.getDate()) , 3+Integer.parseInt(n.getDate()) ,
			4+Integer.parseInt(n.getDate()) , 5+Integer.parseInt(n.getDate()) , 6+Integer.parseInt(n.getDate())};
	
	JComboBox comboDate , comboMovie;
	
	Font font = new Font("Krungthep" , Font.PLAIN , 26);
	Font font2 = new Font("Krungthep" , Font.PLAIN , 16);
	Font font3 = new Font("Krungthep" , Font.PLAIN , 14);
	
	ArrayList<String>arrDate = new ArrayList<String>(0);
	ArrayList<String>arrTime = new ArrayList<String>(0);
	
	boolean flagAdd = false ;
	String lineTime = "";
	
	String nameMovie = "Phee nak 2";
	
	public PageSetMovie() {
		super("Set movie showtime");
		setSize(500,500);
		setLayout(null);
		Dimension s = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)s.getWidth()/2 - this.getWidth()/2 , (int)s.getHeight()/2 - this.getHeight()/2);
		
		lblSetmovie.setBounds(105, 15 , 350,50);
		lblSetmovie.setFont(font);
		add(lblSetmovie);
		
		setJComboMovie();
		comboMovie.setBounds(100, 60 , 300,50);
		comboMovie.setFont(font3);
		add(comboMovie);
		
		lbldate.setBounds(45 , 100 , 350,50);
		lbldate.setFont(font2);
		add(lbldate);
		
		setJComboDate();
		comboDate.setBounds(280, 103 , 100,50);
		comboDate.setFont(font3);
		add(comboDate);
		
		btnAddDate.setBounds(395, 110, 90,35);
		btnAddDate.setFont(font3);
		btnAddDate.addActionListener(this);
		add(btnAddDate);
		
		lblTime.setBounds(45 , 140 , 350,50);
		lblTime.setFont(font2);
		add(lblTime);
		
		fieldTime.setBounds(240, 150 , 140,30);
		fieldTime.setFont(font3);
		fieldTime.addActionListener(this);
		fieldTime.setEnabled(false);
		add(fieldTime);
		
		btnAddTime.setBounds(395, 147, 90,35);
		btnAddTime.setFont(font3);
		btnAddTime.addActionListener(this);
		btnAddTime.setEnabled(false);
		add(btnAddTime);
		
		areaDateTime.setBounds(145 , 200 , 200,200);
		areaDateTime.setFont(font3);
		areaDateTime.setEditable(false);
		add(areaDateTime);
		
		btnOK.setBounds(110 , 430 , 90,35);
		btnOK.setFont(font3);
		btnOK.addActionListener(this);
		btnOK.setEnabled(false);
		add(btnOK);
		
		btncancel.setBounds(290, 430 , 90,35);
		btncancel.setFont(font3);
		btncancel.addActionListener(this);
		add(btncancel);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void setJComboMovie () {
		ArrayList<String>arrMovie = new ArrayList<String>(0);
		
		try {
			Scanner scan = new Scanner(new File("src/EditMovie/NameMovie.txt"));
			while(scan.hasNext()) {
				arrMovie.add(scan.nextLine());
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		String s[] = new String[arrMovie.size()];
		int count = 0 ;
		for(String str : arrMovie) {
			s[count] = str;
			count++;
		}
		
		comboMovie = new JComboBox(s);
	}

	public void setJComboDate () {
		String str[] = new String[date.length];
		int count = 0 ;
		for(int i : date) {
			str[count] = Integer.toString(i);
			count++;
		}
		comboDate = new JComboBox(str);
	}

	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == btnAddDate) {
			arrDate.add(Integer.toString(comboDate.getSelectedIndex()+1));

			if (flagAdd == false) {
				strArea += "date " + comboDate.getSelectedItem() + "\n";
				flagAdd = true;
			}else {
				strArea += "\ndate " + comboDate.getSelectedItem() + "\n";
			}
			btnAddDate.setEnabled(false);
			btnAddTime.setEnabled(true);
			fieldTime.setEnabled(true);
			areaDateTime.setText(strArea);
			
			if(!lineTime.equals(""))arrTime.add(lineTime);
			lineTime = "";
		}else if (e.getSource() == btnAddTime || e.getSource() == fieldTime) {
			comboMovie.setEnabled(false);
			comboDate.setEnabled(false);
			btnAddDate.setEnabled(false);
			
			if((Integer.parseInt(fieldTime.getText().substring(0,2)) < 10 || Integer.parseInt(fieldTime.getText().substring(0,2)) > 23) 
					|| (Integer.parseInt(fieldTime.getText().substring(3)) >59)) {
				JOptionPane.showMessageDialog(null, "Input 10:00 to 23:00");
			}else {
				if(!fieldTime.getText().equals("")) {
					lineTime += fieldTime.getText() + " ";
					strArea += fieldTime.getText() + " ";
					fieldTime.setText("");
					areaDateTime.setText(strArea);
					btnOK.setEnabled(true);
					countTime ++ ;
				}
			}
		}else if (e.getSource() == btnOK) {
			int input = JOptionPane.showConfirmDialog(null, "Confirm Add movie " , "Confirm add movie"
					, JOptionPane.OK_CANCEL_OPTION , JOptionPane.QUESTION_MESSAGE);
			
			if(input == 0) {
				arrTime.add(lineTime);

				int count = 0 ;
				for(String str : arrDate) {
					try {
						PrintWriter writer = new PrintWriter(new FileOutputStream("src/BuyTicket/day/day"+str+".txt" , true));
						
						writer.println(comboMovie.getSelectedItem());
						writer.print("Time ");
						writer.println(arrTime.get(count));
						writer.close();
						
						PrintWriter writer2 = new PrintWriter(new FileOutputStream("src/BuyTicket/Seats/day"+str+".txt" , true));
						
						for(int i = 0 ; i < countTime ; i++) {
							for(int r = 0 ; r < 5 ; r++) {
								for(int  c = 0 ; c < 14 ; c ++) {
									writer2.print("1"); 			// add status movie to Seats folder
								}
							}
							writer2.println();
						}
						writer2.close();
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					}
				}
				new PageEdit();
				this.dispose();
			}
			
		}else if (e.getSource() == btncancel) {
			new PageEdit();
			this.dispose();
		}
	}
}