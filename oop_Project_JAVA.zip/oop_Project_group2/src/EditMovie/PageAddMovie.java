package EditMovie;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import Menu.*;

public class PageAddMovie extends JFrame implements ActionListener{
	JButton btnOK = new JButton("OK");
	JButton btncancel = new JButton("cancel");
	
	JLabel lblName = new JLabel("Name        \n: ");
	JLabel lblDirector = new JLabel("Director  \n: ");
	JLabel lblActors = new JLabel("Actors     \n : ");
	JLabel lblSynopsis = new JLabel("Synopsis\n: ");
	JLabel lblGenre = new JLabel("Genre        \n: ");
	JLabel lblRate = new JLabel("Rate : ");
	JLabel lblTime = new JLabel("Time : ");
	
	JTextField fieldName = new JTextField(10);
	JTextField fieldDirector = new JTextField(10);
	JTextField fieldGenre = new JTextField(10);
	JTextField fieldRate = new JTextField(10);
	JTextField fieldTime = new JTextField(10);
	
	JTextArea areaActors = new JTextArea(5,10);
	JTextArea areaSynopsis = new JTextArea(10,10);
	
	JScrollPane scrActors = new JScrollPane(areaActors);
	JScrollPane scrSynopsis = new JScrollPane(areaSynopsis);
	
	Font font1 = new Font("Krungthep" , Font.PLAIN , 30);
	Font fontButton = new Font("Krungthep" , Font.PLAIN , 20);
	Font fontLabel = new Font("Krungthep" , Font.PLAIN , 18);
	Font fontArea = new Font("Angsana new" , Font.PLAIN , 16);

	public PageAddMovie() {
		setSize(750,500);
		setLayout(null);
		Dimension s = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation((int)s.getWidth()/2 - this.getWidth()/2 , (int)s.getHeight()/2 - this.getHeight()/2);
		
		// set GUI
		setName();
		setGenre();
		setRate();
		setTime();
		setDirector();
		setActors();
		setSynopsis();
		setButton();
		
		setVisible(true);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		
		g.setColor(Color.black);
		g.setFont(font1);
		g.drawString("Add Movie ...", 275, 90);
	}
	
	
	
	public void createMovie() {
		// Create directory(Folder) in sec/Movie
		File file = new File("src/Movie/" + fieldName.getText());
		file.mkdir();
		
		try {
			PrintWriter writer = new PrintWriter(new FileOutputStream("src/EditMovie/NameMovie.txt" , true));
			writer.println(fieldName.getText());
			writer.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			// Create textFile in directory(Folder) fieldName (Name of movie)
			PrintWriter writerName = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Name.txt" , true));
			writerName.print(fieldName.getText());
			writerName.close();
			
			PrintWriter writerGenre = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Genre.txt" , true));
			writerGenre.print(fieldGenre.getText());
			writerGenre.close();
			
			PrintWriter writerRate = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Rate.txt" , true));
			writerRate.print(fieldRate.getText());
			writerRate.close();
			
			PrintWriter writerTime = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Time.txt" , true));
			writerTime.print(fieldTime.getText());
			writerTime.close();
			
			PrintWriter writerDirector = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Director.txt" , true));
			writerDirector.print(fieldDirector.getText());
			writerDirector.close();
			
			PrintWriter writerActors = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Actors.txt" , true));
			writerActors.print(areaActors.getText());
			writerActors.close();
			
			PrintWriter writerSynopsis = new PrintWriter(
					new FileOutputStream("src/Movie/" + fieldName.getText() + "/Synopsis.txt" , true));
			writerSynopsis.print(areaSynopsis.getText());
			writerSynopsis.close();
			
		}catch(IOException e) {
			e.getStackTrace();
		}
	}
	
	public void setName() {
		// add JLabel name
		lblName.setBounds(90 , 90 , 125 , 40);
		lblName.setFont(fontLabel);
		add(lblName);
						
		// add JTextField Name
		fieldName.setFont(fontArea);
		fieldName.setBounds(200,100,450,25);
		add(fieldName);
	}
	
	public void setDirector() {
		// add JLabel Director
		lblDirector.setBounds(90 , 175 , 125 , 40);
		lblDirector.setFont(fontLabel);
		add(lblDirector);
				
		// add JTextField Director
		fieldDirector.setFont(fontArea);
		fieldDirector.setBounds(200 , 185 , 450 , 25);
		add(fieldDirector);
	}
	
	public void setActors() {
		// add JLabel actors
		lblActors.setFont(fontLabel);
		lblActors.setBounds(90 , 240 , 125,40);
		add(lblActors);
		
		// add areaActors
		scrActors.setBounds(205 , 235 , 445 , 60);
		areaActors.setFont(fontArea);
		add(scrActors);
	}
	
	public void setSynopsis() {
		// add JLabel Synopsis
		lblSynopsis.setFont(fontLabel);
		lblSynopsis.setBounds(90 , 305 , 125,40);
		add(lblSynopsis);
		
		// add areaSynopsis
		scrSynopsis.setBounds(205, 315 , 445 , 90);
		areaSynopsis.setFont(fontArea);
		add(scrSynopsis);
	}
	
	public void setButton() {
		// add JButton OK
		btnOK.setFont(fontButton);
		btnOK.setBounds(135, 415, 150,40);
		btnOK.addActionListener(this);
		add(btnOK);
		
		// add JButton cancel
		btncancel.setFont(fontButton);
		btncancel.setBounds(450, 415 , 150,40);
		btncancel.addActionListener(this);
		add(btncancel);
	}
	
	public void setGenre() {
		lblGenre.setBounds(90 , 135 , 125 , 40);
		lblGenre.setFont(fontLabel);
		add(lblGenre);
		
		fieldGenre.setBounds(200 , 142 , 100 , 25);
		fieldGenre.setFont(fontArea);
		add(fieldGenre);
	}
	
	public void setRate() {
		lblRate.setBounds(310 , 135 , 125 , 40);
		lblRate.setFont(fontLabel);
		add(lblRate);
		
		fieldRate.setBounds(375 , 142 , 100 , 25);
		fieldRate.setFont(fontArea);
		add(fieldRate);
	}
	
	public void setTime() {
		lblTime.setBounds(485 , 135 , 125 , 40);
		lblTime.setFont(fontLabel);
		add(lblTime);
		
		fieldTime.setBounds(550 , 142 , 100 , 25);
		fieldTime.setFont(fontArea);
		add(fieldTime);
	}
	
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == btnOK) {
			if (!fieldName.getText().equals("")) {
				createMovie();	// call method for create movie (name , Genre , Rate , Time , director , Actors , Synopsis)
				JOptionPane.showMessageDialog(null, "Create Movie Success.");
				new PageSetMovie();
				this.dispose();
			}else if (fieldName.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "Please enter all information.");
			}
			
		}else if(event.getSource() == btncancel) {
			new PageEdit();
			setVisible(false);
		}
	}
}
